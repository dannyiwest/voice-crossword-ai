# Voice Crossword AI PWA

Fully updated: correct genre handling, local JSON per genre, cache v4.