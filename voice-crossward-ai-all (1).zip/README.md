# Voice Crossword AI PWA

This project is a PWA that uses speech recognition and synthesis to provide a voice-driven crossword quiz.