# Voice Crossword AI PWA

Expanded to six genres: `food`, `entertainment`, `science`, `investing`, `mystery`, `sports`.